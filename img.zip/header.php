<header class="header">
            <div class="header-logo">
            <a class="bottons" href="/">
ГрумRoom</a>
            </div>
            <div class="header-content">
                <a href="#">Главная</a>
                <a href="#">Админ панель</a>
                <a href="#">Личный кабинет</a>
            </div>
            <div class="header-botton">
            <a class="bottons" href="/atoruzonion.php" >Вход</a>
            <a class="bottons"  href="/regustr.php">Регистрация</a>
            </div>
</header>